package com.example.home
import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.provider.MediaStore
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.home.databaseBuku.Buku
import com.example.home.databaseUser.User
import com.example.home.databinding.ActivityMenjualActiviyBinding
import com.example.home.ui.notifications.NotificationsFragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import kotlinx.android.synthetic.main.activity_menjual_activiy.*
import java.io.IOException
import java.util.*

class menjualActivity : AppCompatActivity() {
    private lateinit var binding : ActivityMenjualActiviyBinding
    lateinit var database: DatabaseReference
    lateinit var databaseBuku: DatabaseReference
    lateinit var auth : FirebaseAuth
    lateinit var us : User
    lateinit var buku : Buku
    lateinit var uid : String
    lateinit var imagePath : Uri
    lateinit var bit : Bitmap
    lateinit var pd : ProgressDialog
    var uuid : String = UUID.randomUUID().toString()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMenjualActiviyBinding.inflate(layoutInflater)

        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()
        uid = auth.currentUser?.uid.toString()
        database = FirebaseDatabase.getInstance().getReference("Data_user")

        binding.arrowbackBtn.setOnClickListener(){
            onBackPressed()
        }

        binding.jualBtn.setOnClickListener(){

            val judul = binding.etJudul.text.toString()
            val genre = binding.etGenre.text.toString()
            val sinops= binding.inSinopsis.text.toString()
            val harga = binding.etHarga.text

            if (judul.isEmpty()){
                binding.etJudul.error = "Judul harus diisi"
                binding.etJudul.requestFocus()
                return@setOnClickListener
            }
            if (genre.isEmpty()){
                binding.etGenre.error = "Genre harus diisi"
                binding.etGenre.requestFocus()
                return@setOnClickListener
            }

            if (sinops.isEmpty()){
                binding.inSinopsis.error = "Sinopsis harus diisi"
                binding.inSinopsis.requestFocus()
                return@setOnClickListener
            }
            if(harga.toString().isEmpty()){
                binding.etHarga.error = "Harga harus diisi"
                binding.etHarga.requestFocus()
                return@setOnClickListener
            }

            if (isNumeric(harga.toString())){
                val pg = ProgressDialog(this)
                pg.setTitle("Saving Buku")
                pg.setMessage("Wait a moment...")
                pg.setCancelable(false)
                pg.show()

                val isi = intent.getStringExtra("isiBuku")

                var dataBuku = database.child(uid)
                databaseBuku = FirebaseDatabase.getInstance().getReference("Buku").child(uid)
                database = FirebaseDatabase.getInstance().getReference("Data_user").child(uid).child("User").child("nama_user")
                database.addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val nama = snapshot.getValue(String::class.java)
                        buku = Buku(uuid, judul, genre, isi , sinops, harga.toString().toInt(), true, nama, uid)
                        databaseBuku.child(uuid).setValue(buku).addOnCompleteListener() {
                            if(it.isSuccessful){
                                Handler().postDelayed({
                                    Toast.makeText(applicationContext, "Buku berhasil dijual", Toast.LENGTH_SHORT).show()
                                },1000)

                                Handler().postDelayed({
                                    startActivity(Intent(applicationContext, NotificationsFragment::class.java))
                                },2000)

                            } else {
                                Toast.makeText(applicationContext, "Buku gagal dijual", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {

                    }
                })
            } else {
                binding.etHarga.error = "Harga harus diisi angka"
                binding.etHarga.requestFocus()
                return@setOnClickListener
            }
        }
        gambarBuku()
    }

    fun isNumeric(toCheck: String): Boolean {
        val regex = "-?[0-9]+(\\.[0-9]+)?".toRegex()
        return toCheck.matches(regex)
    }

    //gambarBuku
    fun gambarBuku(){
        binding.ivUploadGambar.setOnClickListener(){
            val foto = Intent(Intent.ACTION_PICK)
            foto.setType("image/")
            startActivityForResult(foto, 1)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if(requestCode == 1 && resultCode == RESULT_OK && data != null){
            imagePath = data.data!!
            getImageinIV()
        } else {
            Toast.makeText(this, "Batal", Toast.LENGTH_SHORT).show()
        }
    }

    fun getImageinIV(){
        try{
            bit = MediaStore.Images.Media.getBitmap(contentResolver, imagePath)
        } catch (e : IOException){
            e.printStackTrace()
        }
        binding.ivUploadGambar.setImageBitmap(bit)
        uploadGambarBuku()

    }

    @SuppressLint("SuspiciousIndentation")
    fun uploadGambarBuku(){
        val pg = ProgressDialog(this)
        pg.setTitle("Uploading image...")
        pg.setMessage("Wait a moment...")
        pg.show()
        pg.setCancelable(false)
        //uuid = UUID.randomUUID().toString()
            FirebaseStorage.getInstance().getReference("GambarBuku").child(uuid).putFile(imagePath).addOnCompleteListener(){
                if(it.isSuccessful){
                    Toast.makeText(this, "Gambar buku berhasil diupload", Toast.LENGTH_SHORT).show()
                    it.result.storage.downloadUrl.addOnCompleteListener(){
                        if (it.isSuccessful){
                            //FirebaseDatabase.getInstance().getReference("Buku").child(uid).child(uuid).child("gambarBuku").setValue(it.result.toString())
                        }
                    }
                } else {
                    Toast.makeText(this, "Gambar buku gagal diupload", Toast.LENGTH_SHORT).show()
                }
                pg.dismiss()
            }
                .addOnProgressListener {
                    val progress = 100.0 * it.bytesTransferred / it.totalByteCount
                    pg.setMessage(" Uploaded "+ progress.toInt() + "%")
                }
    }
}