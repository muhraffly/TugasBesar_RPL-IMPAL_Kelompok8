package com.example.home

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.home.adapter.commentAdapter
import com.example.home.databaseBuku.Comment
import com.example.home.databinding.ActivityCommentRatingBinding
import com.example.home.databinding.ActivityMembeliBukuBinding
import com.example.home.databinding.ActivityTampilCommentBinding
import com.google.firebase.database.*

class tampilComment : AppCompatActivity() {
    private lateinit var binding : ActivityTampilCommentBinding
    private lateinit var dataRef : DatabaseReference
    private lateinit var rv : RecyclerView
    private lateinit var commentAr : ArrayList<Comment>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTampilCommentBinding.inflate(layoutInflater)
        setContentView(binding.root)

        rv = binding.rvComment
        rv.layoutManager = LinearLayoutManager(this)
        rv.setHasFixedSize(true)

        commentAr = arrayListOf<Comment>()

        getCommentBuku()

        binding.backButton.setOnClickListener(){
            onBackPressed()
        }
    }

    private fun getCommentBuku(){
        val tempUUID = intent.getStringExtra("uuid").toString()
        val idPenulis = intent.getStringExtra("idpenulis").toString()
        Log.d("UUID", tempUUID)
        Log.d("ID PENULISSSS", idPenulis)

        dataRef = FirebaseDatabase.getInstance().getReference("Buku").child(idPenulis).child(tempUUID)
        dataRef.child("komentar").addValueEventListener(object  : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
               if (snapshot.exists()){
                   for (comment in snapshot.children){
                       val komen = comment.getValue(Comment::class.java)
                       commentAr.add(komen!!)
                   }

                   rv.adapter = commentAdapter(commentAr, context = this@tampilComment)
               }
            }

            override fun onCancelled(error: DatabaseError) {

            }

        })
    }
}