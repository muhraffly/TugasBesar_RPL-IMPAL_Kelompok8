package com.example.home.adapter

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.home.R
import com.example.home.databaseBuku.Buku
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.io.File

class bookListAdapter (var data :ArrayList<Buku>, var context: Activity? ) :
    RecyclerView.Adapter<bookListAdapter.MyViewHolder>(){
    lateinit var storage : StorageReference
    private lateinit var auth : FirebaseAuth
    private lateinit var uid : String
    private lateinit var bitmap : Bitmap

    private lateinit var mListener: onItemClickListener
    interface onItemClickListener{
        fun onItemClick(position: Int)
    }

    fun setOnItemClickListener(clickListener: onItemClickListener){
        mListener = clickListener
    }

    class MyViewHolder (view: View, clickListener: onItemClickListener) : RecyclerView.ViewHolder(view) {

        val judulbuku = view.findViewById<TextView>(R.id.tv_judulbuku)
        val gambarbuku = view.findViewById<ImageView>(R.id.gambar_buku)
        val genre = view.findViewById<TextView>(R.id.tv_genre)
        val harga = view.findViewById<TextView>(R.id.hrg)
        val rating = view.findViewById<TextView>(R.id.rating)

        init {
            view.setOnClickListener{
                clickListener.onItemClick(adapterPosition)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view : View = LayoutInflater.from(parent.context).inflate(R.layout.cardviewlibrary, parent, false)
        return MyViewHolder(view, mListener)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.judulbuku.text = data[position].judulBuku
        holder.genre.text = data[position].genreBuku
        holder.harga.text = "Rp."+data[position].hargaBuku.toString()
        holder.rating.text = data[position].rate.toString()

    }

    override fun getItemCount(): Int {
        return data.size
    }
}