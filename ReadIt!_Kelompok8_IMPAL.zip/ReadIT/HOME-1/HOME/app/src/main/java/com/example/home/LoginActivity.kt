package com.example.home

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.text.InputType
import android.util.Patterns
import android.widget.Toast
import com.example.home.databaseUser.User
import com.example.home.databinding.ActivityLoginBinding
import com.example.home.sharePreference.constant
import com.example.home.sharePreference.sharePreference
import com.google.firebase.auth.FirebaseAuth
//import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_login.*

import kotlinx.android.synthetic.main.activity_login.login_password_edit_text

class LoginActivity : AppCompatActivity() {
    lateinit var auth : FirebaseAuth
    lateinit var binding : ActivityLoginBinding
    lateinit var user : User

    lateinit var sharedPref : sharePreference
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityLoginBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        sharedPref = sharePreference(this)

        auth = FirebaseAuth.getInstance()

        login_password_edit_text.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        binding.loginButton.setOnClickListener {
            val email = binding.loginUsernameEditText.text.toString()
            val password = binding.loginPasswordEditText.text.toString()

            if (email.isEmpty()){
                binding.loginUsernameEditText.error = "Email harus diisi"
                binding.loginUsernameEditText.requestFocus()
                return@setOnClickListener
            }
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                binding.loginUsernameEditText.error = "Email tidak valid"
                binding.loginUsernameEditText.requestFocus()
                return@setOnClickListener
            }
            if (password.isEmpty()){
                binding.loginPasswordEditText.error = "Password harus diisi"
                binding.loginPasswordEditText.requestFocus()
                return@setOnClickListener
            }

            loginFirebase(email, password)
        }
        binding.signupButton.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
            finish()
        }

    }

    override fun onStart() {
        super.onStart()
        if (sharedPref.getBoolean(constant.PREF_IS_LOGIN)){
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }

    private fun loginFirebase(email: String, password: String) {
        val pg = ProgressDialog(this)
        pg.setTitle("Processing")
        pg.setMessage("Wait a moment...")
        pg.setCancelable(false)
        pg.show()
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this){
                if (it.isSuccessful){
                    sharedPref.put(constant.PREF_EMAIL, email)
                    sharedPref.put(constant.PREF_PASSWORD, password)
                    sharedPref.put(constant.PREF_IS_LOGIN, true)
                    Toast.makeText(this, "Selamat Datang $email", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                } else {
                    Toast.makeText(this, "${it.exception?.message}", Toast.LENGTH_SHORT).show()
                }
                pg.dismiss()
            }
    }
}