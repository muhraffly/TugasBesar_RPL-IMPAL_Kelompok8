package com.example.home

import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.DialogInterface
import android.content.Intent
import android.os.Build

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.annotation.RequiresApi

import com.example.home.adapter.homeAdapter
import com.example.home.databaseBuku.Buku
import com.example.home.databaseUser.User
import com.example.home.databinding.ActivityMembeliBukuBinding

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_membeli_buku.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.UUID


class membeliBuku : AppCompatActivity() {
    private lateinit var binding : ActivityMembeliBukuBinding
    private lateinit var buku : Buku
    private lateinit var uid : String
    private lateinit var auth : FirebaseAuth
    private lateinit var dataBukuBeli : DatabaseReference
    private lateinit var databaseRef : DatabaseReference
    private lateinit var dataSaldoJual : DatabaseReference
    private lateinit var user : User
    private lateinit var saldo : String
    private lateinit var getsaldo : String
    private lateinit var idPenulis : String
    private var idPayment : String = UUID.randomUUID().toString().replace("-","").substring(0,12)
    var stop : Boolean = false
    var stop2 : Boolean = false
    lateinit var pd : ProgressDialog
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMembeliBukuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ambilData()
        lihatKomentarButton()
        backBuyButton()
        readDataUser()
        buying()
    }

    private fun backBuyButton(){
        backBuyBtn.setOnClickListener{
            onBackPressed()
        }
    }

    private fun lihatKomentarButton(){
        binding.liatComment.setOnClickListener(){
            binding.tempUUID.setText(intent.getStringExtra("id"))
            idPenulis = intent.getStringExtra("id_penulis").toString()
            val intent = Intent(this, tampilComment::class.java)
            intent.putExtra("uuid", binding.tempUUID.text)
            intent.putExtra("idpenulis", idPenulis)
            startActivity(intent)

        }
    }

    private fun buying(){
        buyButton.setOnClickListener{
            beliBuku()
        }
    }

    fun readDataUser() {
        auth = FirebaseAuth.getInstance()
        uid = auth.currentUser?.uid.toString()

        if (uid.isNotEmpty()) {
            databaseRef = FirebaseDatabase.getInstance().getReference("Data_user").child(uid).child("Buku").child("BukuTerbeli")
            databaseRef.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    binding.tempUUID.setText(intent.getStringExtra("id"))
                    if (snapshot.exists()){
                        for (idBuku in snapshot.children){
                            if (idBuku.key == binding.tempUUID.text){
                                binding.buyButton.text = "Terbeli"
                                binding.buyButton.isEnabled = false
                            }

                        }
                    }
                }
                override fun onCancelled(error: DatabaseError) {
                }

            })

        }
    }

    private fun ambilData(){
        binding.judulBuku.setText(intent.getStringExtra("judul"))
        binding.sinopsis.setText(intent.getStringExtra("sinopsis"))
        binding.buyButton.setText(intent.getStringExtra("harga"))
        binding.genre.setText("Genre: " + intent.getStringExtra("genre"))
        binding.penulis.setText(intent.getStringExtra("penulis"))
        binding.rate.setText(intent.getStringExtra("rate")).toString()
    }

    private fun beliBuku(){
        binding.tempUUID.setText(intent.getStringExtra("id"))
        binding.tempGenre.setText(intent.getStringExtra("genre"))
        binding.tempIsi.setText(intent.getStringExtra("isi"))
        idPenulis = intent.getStringExtra("id_penulis").toString()

        val judul = binding.judulBuku.text.toString()
        val genre = binding.tempGenre.text.toString()
        val uuid = binding.tempUUID.text.toString()
        val isi = binding.tempIsi.text.toString()
        val sinops = binding.sinopsis.text.toString()
        val harga = binding.buyButton.text.toString().toInt()
        val penulis = binding.penulis.text.toString()
        auth = FirebaseAuth.getInstance()
        uid = auth.currentUser?.uid.toString()
        dataBukuBeli = FirebaseDatabase.getInstance().getReference("Data_user").child(uid).child("Buku").child("BukuTerbeli")

        databaseRef = FirebaseDatabase.getInstance().getReference("Data_user")
        databaseRef.child(uid).child("User").addValueEventListener(object : ValueEventListener{
            @RequiresApi(Build.VERSION_CODES.O)
            override fun onDataChange(snapshot: DataSnapshot) {
                while (!stop){
                    user = snapshot.getValue(User::class.java)!!
                    getsaldo = user.saldo.toString()
                    if (getsaldo.toInt() > harga){
                        buku = Buku(uuid, judul, genre, isi , sinops, harga, true, penulis, idPenulis)
                        dataBukuBeli.child(uuid).setValue(buku)
                        saldo = (getsaldo.toInt() - harga).toString()
                        databaseRef.child(uid).child("User").child("saldo").setValue(saldo.toInt())
                        showAlertDialogSukses()

                    } else {
                        showAlertDialogGagal()
                    }
                    stop = true
                }
            }

            override fun onCancelled(error: DatabaseError) {

            }

        })

        //Tambah saldo penulis
        idPenulis = intent.getStringExtra("id_penulis").toString()
        dataSaldoJual = FirebaseDatabase.getInstance().getReference("Data_user").child(idPenulis)
        dataSaldoJual.child("User").addValueEventListener(object : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                while (!stop2){
                    user = snapshot.getValue(User::class.java)!!
                    getsaldo = user.saldo.toString()
                    Log.d("Get Saldo", getsaldo)
                    saldo = (getsaldo.toInt() + harga).toString()
                    dataSaldoJual.child("User").child("saldo").setValue(saldo.toInt())
                    stop2 = true
                    break

                }
            }

            override fun onCancelled(error: DatabaseError) {

            }

        })


    }
    @RequiresApi(Build.VERSION_CODES.O)
    private fun showAlertDialogSukses(){
        var ad = AlertDialog.Builder(this)
        val tanggal = LocalDate.now()
        var formatTgl = DateTimeFormatter.ofPattern("dd-MM-yyy")
        ad.setTitle("Pembelian Buku Berhasil")
        ad.setMessage("Buku telah berhasil dibeli. " +
                "Segera ke library untuk melihat buku barumu")
        ad.setMessage("ID pembayaran : ${idPayment}\nTanggal : ${formatTgl.format(tanggal)}\nJudul Buku : ${binding.judulBuku.text}\nHarga : Rp.${binding.buyButton.text}")
        ad.setCancelable(false)
        ad.setPositiveButton("OK",DialogInterface.OnClickListener{ dialog, id ->
            dialog.cancel()
            this.finish()
        })
        ad.create()
        ad.show()
    }

    private fun showAlertDialogGagal(){
        var ad = AlertDialog.Builder(this)
        ad.setTitle("Pembelian Buku Gagal")
        ad.setMessage("Maaf, Buku gagal dibeli dikarenakan saldo tidak cukup.")
        ad.setCancelable(false)
        ad.setPositiveButton("OK",DialogInterface.OnClickListener{ dialog, id ->
            dialog.cancel()
            this.finish()
        })
        ad.create()
        ad.show()
    }
}