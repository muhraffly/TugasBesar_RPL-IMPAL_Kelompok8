package com.example.home

import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.SearchView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.home.adapter.homeAdapter
import com.example.home.databaseBuku.Buku
import com.example.home.ui.home.HomeFragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_home.*
import kotlinx.android.synthetic.main.activity_menulis.*
import java.util.*
import kotlin.collections.ArrayList

class Search : AppCompatActivity() {
    private lateinit var auth : FirebaseAuth
    private lateinit var databaseRef : DatabaseReference
    private lateinit var uid : String
    private lateinit var rvBuku : RecyclerView
    private lateinit var rvSearch : RecyclerView
    private lateinit var sv : SearchView
    private var bookAr  = ArrayList<Buku>()
    //private var filteredList = ArrayList<Buku>()
    private lateinit var adapt : homeAdapter
    private lateinit var adapter : homeAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)

        rvBuku = findViewById(R.id.recycleview)
        //rvSearch = findViewById(R.id.recycleview)
        sv = findViewById(R.id.searchview)
        val grid = GridLayoutManager(this, 3)
        grid.orientation = GridLayoutManager.VERTICAL
        rvBuku.setHasFixedSize(true)
        rvBuku.layoutManager = grid

        getDataBuku()

        adapt = homeAdapter(bookAr, this)
        //adapter = homeAdapter(filteredList, this)
        rvBuku.adapter = adapt



        sv.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                filterList(newText)
                return true
            }
        })
    }

    private fun filterList(query : String?){
        if (query != null){
            var filteredList = ArrayList<Buku>()
            for (data in bookAr){
                if (data.judulBuku.toString().toLowerCase(Locale.ROOT).contains(query)){
                    filteredList.add(data)
                }
            }

            if (filteredList.isEmpty()){
                Toast.makeText(this, "Buku tidak ditemukan", Toast.LENGTH_SHORT).show()
            } else {
                val adapterr = homeAdapter(filteredList, this)
                rvBuku.adapter = adapterr
                adapterr.setFilteredList(filteredList)
                adapterr.setOnItemClickListener(object : homeAdapter.onItemClickListener {
                    override fun onItemClick(position: Int) {
                        if (uid == filteredList[position].id_penulis) {
                            showAlertDialog()

                        } else {
                            val intent = Intent(this@Search, membeliBuku::class.java)
                            intent.putExtra("judul", filteredList[position].judulBuku)
                            intent.putExtra("sinopsis", filteredList[position].sinopsis)
                            intent.putExtra("harga", filteredList[position].hargaBuku.toString())
                            intent.putExtra("id", filteredList[position].idBuku)
                            intent.putExtra("isi", filteredList[position].isiBuku)
                            intent.putExtra("genre", filteredList[position].genreBuku)
                            intent.putExtra("penulis", filteredList[position].penulis)
                            intent.putExtra("id_penulis", filteredList[position].id_penulis)
                            intent.putExtra("rate", filteredList[position].rate.toString())
                            startActivity(intent)
                        }
                    }
                })
            }

        }
    }

    private fun getDataBuku(){
        auth = FirebaseAuth.getInstance()
        uid = auth.currentUser?.uid.toString()
        databaseRef = FirebaseDatabase.getInstance().getReference("Buku")
        databaseRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if(snapshot.exists()){
                    for(bookSnap in snapshot.children){
                        if (snapshot.exists()){
                            for(bookSn in bookSnap.children){
                                val book = bookSn.getValue(Buku::class.java)
                                bookAr.add(book!!)
                            }
                        }
                    }
                    adapt = homeAdapter(bookAr, this@Search)
                    rvBuku.adapter = adapt

                    adapt.setOnItemClickListener(object : homeAdapter.onItemClickListener{
                        override fun onItemClick(position: Int) {
                            if (uid == bookAr[position].id_penulis){
                                showAlertDialog()

                            }else {
                                val intent = Intent(this@Search, membeliBuku::class.java)
                                intent.putExtra("judul", bookAr[position].judulBuku)
                                intent.putExtra("sinopsis", bookAr[position].sinopsis)
                                intent.putExtra("harga", bookAr[position].hargaBuku.toString())
                                intent.putExtra("id", bookAr[position].idBuku)
                                intent.putExtra("isi", bookAr[position].isiBuku)
                                intent.putExtra("genre", bookAr[position].genreBuku)
                                intent.putExtra("penulis", bookAr[position].penulis)
                                intent.putExtra("id_penulis", bookAr[position].id_penulis)
                                intent.putExtra("rate", bookAr[position].rate.toString())
                                startActivity(intent)
                            }
                        }
                    })
                }
            }

            override fun onCancelled(error: DatabaseError) {
            }

        })
    }
    private fun showAlertDialog(){
        var ad = AlertDialog.Builder(this)
        ad.setTitle("Information")
        ad.setMessage("Tidak bisa beli buku milikmu")
        ad.setCancelable(false)
        ad.setPositiveButton("OK", DialogInterface.OnClickListener{ dialog, id ->
            dialog.cancel()

        })
        ad.create()
        ad.show()
    }
}