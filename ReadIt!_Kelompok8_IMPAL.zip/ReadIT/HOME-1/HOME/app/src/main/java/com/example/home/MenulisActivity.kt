package com.example.home

import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.home.databaseBuku.Buku
import com.example.home.databaseUser.User
import com.example.home.databinding.ActivityMenulisBinding
import com.example.home.ui.notifications.NotificationsFragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import java.util.UUID

class MenulisActivity : AppCompatActivity() {
    private lateinit var binding : ActivityMenulisBinding
    lateinit var database: DatabaseReference
    lateinit var databaseBuku: DatabaseReference
    lateinit var auth : FirebaseAuth
    lateinit var us : User
    lateinit var buku : Buku
    lateinit var uid : String
    lateinit var isi : EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMenulisBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ambilData()

        auth = FirebaseAuth.getInstance()
        uid = auth.currentUser?.uid.toString()
        database = FirebaseDatabase.getInstance().getReference("Data_user")

        binding.arrowBackBtn.setOnClickListener() {
            onBackPressed()
        }

        binding.saveTulisBtn.setOnClickListener() {
            val isi = binding.inputIsi.text.toString()

            if (isi.isEmpty()) {
                binding.inputIsi.error = "Isi Buku harus diisi"
                binding.inputIsi.requestFocus()
                return@setOnClickListener
            }

            var ad = AlertDialog.Builder(this)
            ad.setTitle("Confirm")
            ad.setMessage("Ingin menjual buku?")
            ad.setCancelable(false)
            ad.setPositiveButton("Yes", DialogInterface.OnClickListener{ dialog, id ->
                val intent = Intent(this@MenulisActivity, menjualActivity::class.java)
                intent.putExtra("isiBuku", isi)
                startActivity(intent)
                this.finish()
                dialog.cancel()
            })
            ad.setNegativeButton("No", DialogInterface.OnClickListener{ dialog, id ->
                dialog.cancel()
                databaseBuku = FirebaseDatabase.getInstance().getReference("Data_user").child(uid).child("Buku").child("BukuDraft").child(UUID.randomUUID().toString())
                buku = Buku(null, "(draft)", null , isi, null, null, false, "", uid)
                databaseBuku.setValue(buku).addOnCompleteListener() {
                    if(it.isSuccessful){
                        Toast.makeText(this, "Buku disimpan didraft", Toast.LENGTH_SHORT).show()

                    } else {
                        Toast.makeText(this, "Buku gagal dijual", Toast.LENGTH_SHORT).show()
                    }
                    startActivity(Intent(this, NotificationsFragment::class.java))
                }
            })
            var alert = ad.create()
            alert.show()
        }
    }

    private fun ambilData(){
        binding.inputIsi.setText(intent.getStringExtra("isi"))
    }
}
