package com.example.home

import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.example.home.databaseBuku.Buku
import com.example.home.databaseUser.User
import com.example.home.databinding.ActivityInfoBukuJualBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_info_buku_jual.*


class infoBukuJual : AppCompatActivity() {
    private lateinit var binding : ActivityInfoBukuJualBinding
    private lateinit var buku : Buku
    private lateinit var uid : String
    private lateinit var auth : FirebaseAuth
    private lateinit var dataBukuBeli : DatabaseReference
    private lateinit var databaseRef : DatabaseReference
    private lateinit var dataSaldoJual : DatabaseReference
    private lateinit var user : User
    private lateinit var saldo : String
    private lateinit var getsaldo : String
    private lateinit var idPenulis : String
    var stop : Boolean = false
    var stop2 : Boolean = false
    lateinit var pd : ProgressDialog
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInfoBukuJualBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ambilData()
        lihatKomentarBtn()
        backBuyButton()
    }

    private fun backBuyButton(){
        back.setOnClickListener{
            onBackPressed()
        }
    }

    private fun lihatKomentarBtn(){
        binding.viewComment.setOnClickListener(){
            binding.tempUUID.setText(intent.getStringExtra("id"))
            idPenulis = intent.getStringExtra("id_penulis").toString()
            val intent = Intent(this, tampilComment::class.java)
            intent.putExtra("uuid", binding.tempUUID.text)
            intent.putExtra("idpenulis", idPenulis)
            startActivity(intent)
        }
    }

    private fun ambilData(){
        binding.judul.setText(intent.getStringExtra("judul"))
        binding.sinops.setText(intent.getStringExtra("sinopsis"))
        binding.genre.setText("Genre: " + intent.getStringExtra("genre"))
        binding.penulis.setText(intent.getStringExtra("penulis"))
        binding.rates.setText(intent.getStringExtra("rate")).toString()
        binding.tempUUID.setText(intent.getStringExtra("id"))
    }
}