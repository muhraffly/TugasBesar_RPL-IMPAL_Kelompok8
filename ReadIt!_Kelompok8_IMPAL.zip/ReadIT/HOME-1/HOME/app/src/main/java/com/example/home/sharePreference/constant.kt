package com.example.home.sharePreference

class constant {
    companion object{
        val PREF_IS_LOGIN = "PREF_IS_LOGIN"
        val PREF_EMAIL = "PREF_EMAIL"
        val PREF_PASSWORD = "PREF_PASSWORD"
    }
}