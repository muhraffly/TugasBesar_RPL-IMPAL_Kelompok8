package com.example.home.adapter

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.home.R
import com.example.home.databaseBuku.Buku

class libraryAdapter (var data :ArrayList<Buku>, var context: Activity? ) :
    RecyclerView.Adapter<libraryAdapter.MyViewHolder>(){
    private lateinit var mListener: onItemClickListener
    interface onItemClickListener{
        fun onItemClick(position: Int)
    }

    fun setOnItemClickListener(clickListener: onItemClickListener){
        mListener = clickListener
    }

    class MyViewHolder (view: View, clickListener: onItemClickListener) : RecyclerView.ViewHolder(view) {
        val judulbuku = view.findViewById<TextView>(R.id.tv_judulbuku)
        val gambarbuku = view.findViewById<ImageView>(R.id.gambar_buku)
        val genre = view.findViewById<TextView>(R.id.tv_genre)
        val harga = view.findViewById<TextView>(R.id.hrg)
        val rating = view.findViewById<TextView>(R.id.rating)
        val star = view.findViewById<ImageView>(R.id.star)

        init {
            view.setOnClickListener{
                clickListener.onItemClick(adapterPosition)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view : View = LayoutInflater.from(parent.context).inflate(R.layout.cardviewlibrary, parent, false)
        return MyViewHolder(view, mListener)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.judulbuku.text = data[position].judulBuku
        holder.genre.text = data[position].genreBuku
        holder.rating.text = ""
        holder.star.visibility = View.INVISIBLE
    }

    override fun getItemCount(): Int {
        return data.size
    }
}