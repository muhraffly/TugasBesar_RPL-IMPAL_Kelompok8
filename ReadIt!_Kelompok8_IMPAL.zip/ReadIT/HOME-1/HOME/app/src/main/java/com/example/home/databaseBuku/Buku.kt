package com.example.home.databaseBuku

import android.graphics.Bitmap
import android.os.Parcelable
import android.widget.ImageView
import kotlinx.android.parcel.Parcelize


class Buku() {
    var idBuku: String? = null
    var judulBuku: String? = null
    var genreBuku: String? = null
    var gambarBuku: Int = 0
    var statJual : Boolean = false
    var hargaBuku: Int? = null
    var isiBuku : String? = null
    var sinopsis: String? = null
    var comment: String? = null
    var rate: Double = 0.0
    var penulis : String? = null
    var id_penulis : String? = null

    constructor(id : String?, judul:String?, genre:String?, isi:String?, sinops:String?, harga:Int?, status : Boolean, kreator : String?, idKreator : String?) : this() {
        this.idBuku = id
        this.judulBuku = judul
        this.genreBuku = genre
        this.isiBuku = isi
        this.sinopsis = sinops
        this.hargaBuku = harga
        this.statJual = status
        this.penulis = kreator
        this.id_penulis = idKreator
    }

}
