package com.example.home.databaseUser

class User (){
    var id_user:String?=null
    var Email:String?=null
    val Password:String?=null
    var Nama_user:String?=null
    var No_Telepon:String?=null
    var Alamat:String?=null
    val library:String?=null
    var saldo: Int = 200000

    constructor(id : String?, Nama:String?, Email:String?, Alamat:String?, tlp:String?) : this() {
        this.id_user = id
        this.Nama_user=Nama
        this.Email = Email
        this.Alamat = Alamat
        this.No_Telepon = tlp
    }
}