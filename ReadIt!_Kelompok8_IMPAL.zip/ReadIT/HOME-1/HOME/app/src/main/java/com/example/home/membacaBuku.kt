package com.example.home

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.home.databinding.ActivityMembacaBukuBinding

class membacaBuku : AppCompatActivity() {
    private lateinit var binding : ActivityMembacaBukuBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMembacaBukuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.backBtn.setOnClickListener(){
            onBackPressed()
        }
        ambilData()


        binding.ivComment.setOnClickListener(){
            val intent = Intent(this, CommentRating::class.java)
            intent.putExtra("idBuku", binding.tempIDbuku.text)
            intent.putExtra("idPenulis", binding.tempIDpenulis.text)
            startActivity(intent)
        }
    }

    private fun ambilData(){
        binding.judulBuku.text = intent.getStringExtra("judul").toString()
        binding.isiBuku.text = intent.getStringExtra("isi").toString()
        binding.tempIDbuku.setText(intent.getStringExtra("id")).toString()
        binding.tempIDpenulis.setText(intent.getStringExtra("idPenulis")).toString()
    }
}