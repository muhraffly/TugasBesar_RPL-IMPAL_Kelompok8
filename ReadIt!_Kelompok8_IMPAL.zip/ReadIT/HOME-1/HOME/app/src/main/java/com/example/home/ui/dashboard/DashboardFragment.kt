package com.example.home.ui.dashboard

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.home.R
import com.example.home.adapter.homeAdapter
import com.example.home.adapter.libraryAdapter
import com.example.home.databaseBuku.Buku
import com.example.home.databinding.FragmentDashboardBinding
import com.example.home.membacaBuku
import com.example.home.membeliBuku
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.fragment_dashboard.view.*

class DashboardFragment : Fragment() {
    private var _binding: FragmentDashboardBinding? = null
    private lateinit var rvBukuBeli : RecyclerView
    private val binding get() = _binding!!
    private lateinit var auth : FirebaseAuth
    private lateinit var databaseRef : DatabaseReference
    private lateinit var uid : String
    private lateinit var bookAr : ArrayList<Buku>

    // This property is only valid between onCreateView and
    // onDestroyView.
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val dashboardViewModel =
            ViewModelProvider(
                this,
                ViewModelProvider.NewInstanceFactory()
            ).get(DashboardViewModel::class.java)

        val view = inflater.inflate(R.layout.fragment_dashboard, container, false)
        //val root: View = binding.root

        val grid = GridLayoutManager(activity, 3)
        grid.orientation = GridLayoutManager.VERTICAL
        rvBukuBeli = view.findViewById(R.id.rv_bukuLibrary)



        rvBukuBeli.setHasFixedSize(true)
        rvBukuBeli.layoutManager = grid
        bookAr = arrayListOf<Buku>()
        getDataBuku()
        
        return view
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun getDataBuku(){
        auth = FirebaseAuth.getInstance()
        uid = auth.currentUser?.uid.toString()
        databaseRef = FirebaseDatabase.getInstance().getReference("Data_user").child(uid).child("Buku").child("BukuTerbeli")
        databaseRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if(snapshot.exists()){
                    for(bookSnap in snapshot.children){
                        val book = bookSnap.getValue(Buku::class.java)
                        bookAr.add(book!!)
                        }
                    }
                    val bAdapter = libraryAdapter(bookAr, context = activity)
                    rvBukuBeli.adapter = bAdapter

                    bAdapter.setOnItemClickListener(object : libraryAdapter.onItemClickListener{
                        override fun onItemClick(position: Int) {
                            val intent = Intent(context, membacaBuku::class.java)
                            intent.putExtra("judul", bookAr[position].judulBuku)
                            intent.putExtra("sinopsis", bookAr[position].sinopsis)
                            intent.putExtra("harga", bookAr[position].hargaBuku.toString())
                            intent.putExtra("id", bookAr[position].idBuku)
                            intent.putExtra("isi", bookAr[position].isiBuku)
                            intent.putExtra("genre", bookAr[position].genreBuku)
                            intent.putExtra("idPenulis", bookAr[position].id_penulis)
                            startActivity(intent)
                        }

                    })
                }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }



        })
    }

}