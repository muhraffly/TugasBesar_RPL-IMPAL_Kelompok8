package com.example.home

import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.example.home.databaseBuku.Buku
import com.example.home.databaseUser.User
import com.example.home.ui.dashboard.DashboardFragment
import com.example.home.ui.home.HomeFragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_comment_rating.*
import kotlinx.android.synthetic.main.activity_membaca_buku.*
import kotlinx.android.synthetic.main.cardviewlibrary.*
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat

class CommentRating : AppCompatActivity() {
    private lateinit var uid : String
    private lateinit var auth : FirebaseAuth
    private lateinit var database : DatabaseReference
    private lateinit var databaseRef : DatabaseReference
    private lateinit var user : User
    private var stop : Boolean = false
    private var stop2 : Boolean = false
    private lateinit var buku : Buku
    private lateinit var getRate : String
    private var total : Double = 0.0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_comment_rating)

        ratingBar.rating = .0f
        ratingBar.stepSize = .5f

        nantiSaja_btn.setOnClickListener(){
            onBackPressed()
        }

        ratingBar.setOnRatingBarChangeListener { ratingBar, rating, fromUser ->
            rating_btn.setOnClickListener() {
                val komen = et_komentar.text.toString()
                val idBuku = intent.getStringExtra("idBuku").toString()
                val idPenulis = intent.getStringExtra("idPenulis").toString()
                auth = FirebaseAuth.getInstance()
                uid = auth.currentUser?.uid.toString()
                database = FirebaseDatabase.getInstance().getReference("Buku").child(idPenulis).child(idBuku)
                database.addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        while (!stop) {
                            buku = snapshot.getValue(Buku::class.java)!!
                            getRate = buku.rate.toString()
                            if (getRate.toDouble() == 0.0) {
                                total = rating.toDouble()
                            } else {
                                total = (getRate.toDouble() + rating) / 2
                            }
                            val bd = BigDecimal(total)
                            val totalFix = bd.setScale(1, RoundingMode.FLOOR)
                            database.child("rate").setValue(totalFix.toDouble())
                            database.child("komentar").child(uid).child("komentar").setValue(komen.toString())
                            database.child("komentar").child(uid).child("rating").setValue(rating.toDouble())
                            showAlertDialogSukses()
                            stop = true
                        }

                    }

                    override fun onCancelled(error: DatabaseError) {

                    }

                })

                databaseRef = FirebaseDatabase.getInstance().getReference("Data_user")
                //database = FirebaseDatabase.getInstance().getReference("Buku").child(idPenulis).child(idBuku)
                databaseRef.child(uid).child("User").addValueEventListener(object : ValueEventListener{
                    override fun onDataChange(snapshot: DataSnapshot) {
                        while (!stop2){
                            user = snapshot.getValue(User::class.java)!!
                            val nama = user.Nama_user.toString()
                            database.child("komentar").child(uid).child("nama_user").setValue(nama)
                            stop2 = true
                            break
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {

                    }

                })
            }
        }
    }

    private fun showAlertDialogSukses(){
        var ad = AlertDialog.Builder(this)
        ad.setTitle("Information")
        ad.setMessage("Terima kasih sudah menilai. Yuk baca buku yang lain ^_^")
        ad.setCancelable(false)
        ad.setPositiveButton("OK", DialogInterface.OnClickListener{ dialog, id ->
            dialog.cancel()
            this.finish()
            onBackPressed()
        })
        ad.create()
        ad.show()
    }
}