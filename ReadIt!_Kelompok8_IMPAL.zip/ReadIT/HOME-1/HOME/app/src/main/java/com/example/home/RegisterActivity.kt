package com.example.home

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.text.InputType
import android.util.Patterns
import android.widget.EditText
import android.widget.Toast
import com.example.home.databaseBuku.Buku
import com.example.home.databaseUser.User
import com.example.home.databinding.ActivityLoginBinding
//import kotlinx.android.synthetic.main.activity_register.*
import com.example.home.databinding.ActivityRegisterBinding
import com.example.home.ui.notifications.NotificationsFragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_membeli_buku.*
import kotlinx.android.synthetic.main.activity_register.*
import kotlinx.android.synthetic.main.activity_set_profile.view.*

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding : ActivityRegisterBinding
    private lateinit var auth : FirebaseAuth
    lateinit var database : DatabaseReference
    var iUser : Int? = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        reg_password_edit_text.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD

        auth = FirebaseAuth.getInstance()


        binding.signInButton.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        binding.registerBtn.setOnClickListener {
            val email = binding.regEmailEditText.text.toString()
            val password = binding.regPasswordEditText.text.toString()

            if (email.isEmpty()){
                binding.regEmailEditText.error = "Email harus diisi"
                binding.regEmailEditText.requestFocus()
                return@setOnClickListener
            }
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                binding.regEmailEditText.error = "Email tidak valid"
                binding.regEmailEditText.requestFocus()
                return@setOnClickListener
            }
            if (password.isEmpty()){
                binding.regPasswordEditText.error = "Password harus diisi"
                binding.regPasswordEditText.requestFocus()
                return@setOnClickListener
            }
            if (password.length < 8){
                binding.regPasswordEditText.error = "Password harus terdiri dari 8 karakter"
                binding.regPasswordEditText.requestFocus()
                return@setOnClickListener
            }
            registFirebase(email, password)
            this.iUser?.inc()
            this.iUser = this.iUser
        }
    }

    private fun registFirebase(email: String, password: String) {
        val pg = ProgressDialog(this)
        pg.setTitle("Processing")
        pg.setMessage("Wait a moment...")
        pg.setCancelable(false)
        pg.show()

        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this){
                if (it.isSuccessful){
                    createDatabase()
                    Toast.makeText(this, "Register Berhasil", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, LoginActivity::class.java))
                    finish()
                } else {
                    Toast.makeText(this, "${it.exception?.message}", Toast.LENGTH_SHORT).show()
                }
                pg.dismiss()
            }
    }

    private fun createDatabase(){
        val nama = "User_$iUser"
        val email = binding.regEmailEditText.text.toString()
        val alamat = ""
        val tlp = ""
        val uid = auth.currentUser?.uid
        var inputUid = uid.toString()

        database = FirebaseDatabase.getInstance().getReference("Data_user")

        val user = User(inputUid, nama, email, alamat, tlp)
        if (uid != null){
            database.child(uid).child("User").setValue(user).addOnSuccessListener {
                binding.regEmailEditText.text?.clear()
            }.addOnFailureListener{
            }

        }
    }
}