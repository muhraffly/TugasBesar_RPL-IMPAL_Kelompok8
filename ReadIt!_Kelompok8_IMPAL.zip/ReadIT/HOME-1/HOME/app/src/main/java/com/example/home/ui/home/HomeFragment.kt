package com.example.home.ui.home

import android.app.AlertDialog
import android.content.DialogInterface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import android.content.Intent
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.home.R
import com.example.home.Search
import com.example.home.adapter.homeAdapter
import com.example.home.databaseBuku.Buku
import com.example.home.databinding.FragmentHomeBinding
import com.example.home.membeliBuku
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.fragment_home.view.*

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private lateinit var rvBukuHomeNew : RecyclerView
    private lateinit var rvBukuHomePop : RecyclerView
    private lateinit var auth : FirebaseAuth
    private lateinit var databaseRef : DatabaseReference
    private lateinit var uid : String
    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    private lateinit var bookAr : ArrayList<Buku>

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val homeViewModel =
            ViewModelProvider(
                this,
                ViewModelProvider.NewInstanceFactory()
            ).get(HomeViewModel::class.java)

        //_binding = FragmentHomeBinding.inflate(inflater, container, false)
        val view = inflater.inflate(R.layout.fragment_home, container, false)
        //val root: View = binding.root

        val grid1 = GridLayoutManager(activity, 3)
        grid1.orientation = GridLayoutManager.VERTICAL
        rvBukuHomeNew = view.findViewById(R.id.rv_home_buku)

        rvBukuHomeNew.setHasFixedSize(true)
        rvBukuHomeNew.layoutManager = grid1

        bookAr = arrayListOf<Buku>()
        getDataBuku()

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        view.search.setOnClickListener {
            val intent = Intent(requireContext(), Search::class.java)
            startActivity(intent)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun getDataBuku(){
        auth = FirebaseAuth.getInstance()
        uid = auth.currentUser?.uid.toString()
        databaseRef = FirebaseDatabase.getInstance().getReference("Buku")
        databaseRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if(snapshot.exists()){
                    for(bookSnap in snapshot.children){
                        if (snapshot.exists()){
                            for(bookSn in bookSnap.children){
                                val book = bookSn.getValue(Buku::class.java)
                                bookAr.add(book!!)
                            }
                        }
                    }
                    val bAdapter = homeAdapter(bookAr, context = activity)
                    rvBukuHomeNew.adapter = bAdapter

                    bAdapter.setOnItemClickListener(object : homeAdapter.onItemClickListener{
                        override fun onItemClick(position: Int) {
                            if (uid == bookAr[position].id_penulis){
                                showAlertDialog()
                            } else {
                                val intent = Intent(context, membeliBuku::class.java)
                                intent.putExtra("judul", bookAr[position].judulBuku)
                                intent.putExtra("sinopsis", bookAr[position].sinopsis)
                                intent.putExtra("harga", bookAr[position].hargaBuku.toString())
                                intent.putExtra("id", bookAr[position].idBuku)
                                intent.putExtra("isi", bookAr[position].isiBuku)
                                intent.putExtra("genre", bookAr[position].genreBuku)
                                intent.putExtra("penulis", bookAr[position].penulis)
                                intent.putExtra("id_penulis", bookAr[position].id_penulis)
                                intent.putExtra("rate", bookAr[position].rate.toString())
                                startActivity(intent)
                            }

                        }

                    })
                }
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }

        })
    }

    private fun showAlertDialog(){
        var ad = AlertDialog.Builder(context)
        ad.setTitle("Information")
        ad.setMessage("Tidak bisa beli buku milikmu")
        ad.setCancelable(false)
        ad.setPositiveButton("OK", DialogInterface.OnClickListener{ dialog, id ->
            dialog.cancel()

        })
        ad.create()
        ad.show()
    }

}