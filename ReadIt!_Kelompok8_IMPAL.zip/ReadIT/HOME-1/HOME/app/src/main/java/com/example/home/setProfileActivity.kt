package com.example.home

import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.home.databaseUser.User
import com.example.home.databinding.ActivitySetProfileBinding
import com.example.home.sharePreference.constant
import com.example.home.sharePreference.sharePreference
import com.example.home.ui.notifications.NotificationsFragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.io.File
import java.io.IOException


class setProfileActivity : AppCompatActivity() {

    lateinit var binding: ActivitySetProfileBinding
    lateinit var database: DatabaseReference
    lateinit var auth : FirebaseAuth
    lateinit var us : User
    lateinit var uid : String
    private lateinit var sharepref : sharePreference
    lateinit var imagePath : Uri
    lateinit var bit : Bitmap
    lateinit var storage : StorageReference
    lateinit var pd : ProgressDialog
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharepref = sharePreference(this)
        binding = ActivitySetProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()
        uid = auth.currentUser?.uid.toString()
        database = FirebaseDatabase.getInstance().getReference("Data_user")

        readData()

        binding.arrowBackBtn.setOnClickListener(){
            onBackPressed()
        }

        binding.saveProfileButton.setOnClickListener{
            val nama = binding.setProfNamaEditText.text.toString()
            val email = binding.setProfEmailEditText.text.toString()
            val alamat = binding.setProfAlamatEditText.text.toString()
            val telepon = binding.setProfTeleponEditText.text.toString()
            val inputUid = uid

            val user = User(inputUid, nama, email, alamat, telepon)
            if (uid != null){
                if (nama.isEmpty()){
                    binding.setProfNamaEditText.error = "Nama harus diisi"
                    binding.setProfNamaEditText.requestFocus()
                    return@setOnClickListener
                }
                if (email.isEmpty()){
                    binding.setProfEmailEditText.error = "Email harus diisi"
                    binding.setProfEmailEditText.requestFocus()
                    return@setOnClickListener
                }

                if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                    binding.setProfEmailEditText.error = "Email tidak valid"
                    binding.setProfEmailEditText.requestFocus()
                    return@setOnClickListener
                }

                if (alamat.isEmpty()){
                    binding.setProfAlamatEditText.error = "Alamat harus diisi"
                    binding.setProfAlamatEditText.requestFocus()
                    return@setOnClickListener
                }

                if (telepon.isEmpty()){
                    binding.setProfTeleponEditText.error = "Telepon harus diisi"
                    binding.setProfTeleponEditText.requestFocus()
                    return@setOnClickListener
                }

                if(telepon.length <= 11 || telepon.length > 14){
                    binding.setProfTeleponEditText.error = "No telepon tidak valid"
                    binding.setProfTeleponEditText.requestFocus()
                    return@setOnClickListener
                }

                if(!isNumeric(telepon)){
                    binding.setProfTeleponEditText.error = "No telepon tidak valid"
                    binding.setProfTeleponEditText.requestFocus()
                    return@setOnClickListener
                }


                val pg = ProgressDialog(this)
                pg.setTitle("Updating profile")
                pg.setMessage("Wait a moment...")
                pg.show()
                pg.setCancelable(false)

                database.child(uid).child("User").setValue(user).addOnCompleteListener {
                    if (it.isSuccessful){
                        Toast.makeText(this, "Update Berhasil", Toast.LENGTH_SHORT).show()
                        startActivity(Intent(this, NotificationsFragment::class.java))
                    }
                    else{
                        Toast.makeText(this, "Update Gagal", Toast.LENGTH_SHORT).show()
                        startActivity(Intent(this, NotificationsFragment::class.java))
                    }
                }
            }
            Toast.makeText(this, "Memproses", Toast.LENGTH_SHORT).show()
        }
        fotoProfil()

        logout()
    }

    fun isNumeric(toCheck: String): Boolean {
        val regex = "-?[0-9]+(\\.[0-9]+)?".toRegex()
        return toCheck.matches(regex)
    }

    fun readData(){
        showProgressDialog()
        val uid = auth.currentUser?.uid
        if ( uid!!.isNotEmpty()){
            database.child(uid!!).child("User").addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    us = snapshot.getValue(User::class.java)!!
                    binding.setProfIdEditText.setText(uid)
                    binding.setProfIdEditText.inputType = 0
                    binding.setProfNamaEditText.setText(us.Nama_user)
                    binding.setProfEmailEditText.setText(us.Email)
                    binding.setProfEmailEditText.inputType = 0
                    binding.setProfAlamatEditText.setText(us.Alamat)
                    binding.setProfTeleponEditText.setText(us.No_Telepon)
                    storage = FirebaseStorage.getInstance().reference.child("FotoProfil/$uid")
                    val localfile = File.createTempFile("tempImage", "jpg")
                    storage.getFile(localfile).addOnSuccessListener {
                        val bitmap = BitmapFactory.decodeFile(localfile.absolutePath)
                        binding.ivUploadProfil.setImageBitmap(bitmap)
                        closeProgressDialog()

                    }.addOnFailureListener{
                        closeProgressDialog()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    closeProgressDialog()
                }
            })

        }
    }

    fun logout(){
        binding.logoutBtn.setOnClickListener {
            var ad = AlertDialog.Builder(this)
            ad.setTitle("Confirm Logout")
            sharepref.put(constant.PREF_IS_LOGIN, false)
            ad.setMessage("Are you sure want to logout?")
            ad.setCancelable(false)
            ad.setPositiveButton("Yes", DialogInterface.OnClickListener{ dialog, id ->
                sharepref.clear()
                val pg = ProgressDialog(this)
                pg.setTitle("Logout")
                pg.setMessage("Wait a moment...")
                pg.setCancelable(false)
                pg.show()
                Toast.makeText(this, "Anda telah Logout", Toast.LENGTH_SHORT).show()
                this.finish()
                dialog.cancel()
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
            })
            ad.setNegativeButton("No", DialogInterface.OnClickListener{ dialog, id ->
                dialog.cancel()
            })

            var alert = ad.create()
            alert.show()

        }
    }

    //Foto Profil
    fun fotoProfil(){
        binding.ivUploadProfil.setOnClickListener(){
            val foto = Intent(Intent.ACTION_PICK)
            foto.setType("image/")
            startActivityForResult(foto, 1)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if(requestCode == 1 && resultCode == RESULT_OK && data != null){
            imagePath = data.data!!
            getImageinIV()
        } else {
            Toast.makeText(this, "Batal", Toast.LENGTH_SHORT).show()
        }
    }

    fun getImageinIV(){
        try{
            bit = MediaStore.Images.Media.getBitmap(contentResolver, imagePath)
        } catch (e : IOException){
            e.printStackTrace()
        }
        binding.ivUploadProfil.setImageBitmap(bit)
        uploadFotoProfil()

    }

    fun uploadFotoProfil(){
        val pg = ProgressDialog(this)
        pg.setTitle("Uploading image...")
        pg.setMessage("Wait a moment...")
        pg.show()
        pg.setCancelable(false)
            FirebaseStorage.getInstance().getReference("FotoProfil").child(uid).putFile(imagePath).addOnCompleteListener(){
                if(it.isSuccessful){
                    Toast.makeText(this, "Foto profil berhasil diupload", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Foto profil gagal diupload", Toast.LENGTH_SHORT).show()
                }
                pg.dismiss()
            }
                .addOnProgressListener {
                    val progress = 100.0 * it.bytesTransferred / it.totalByteCount
                    pg.setMessage(" Uploaded "+ progress.toInt() + "%")
                }
    }

    private fun showProgressDialog(){
        pd = ProgressDialog(this)
        pd.setTitle("Loading")
        pd.setMessage("Wait a moment...")
        pd.setCancelable(false)
        pd.show()
    }

    private fun closeProgressDialog(){
        pd.dismiss()
    }
}


