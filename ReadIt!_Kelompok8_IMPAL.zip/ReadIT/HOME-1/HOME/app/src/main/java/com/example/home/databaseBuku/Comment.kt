package com.example.home.databaseBuku

class Comment() {
    var nama_user : String? = null
    var komentar : String? = null
    var rating : Double = 0.0
}