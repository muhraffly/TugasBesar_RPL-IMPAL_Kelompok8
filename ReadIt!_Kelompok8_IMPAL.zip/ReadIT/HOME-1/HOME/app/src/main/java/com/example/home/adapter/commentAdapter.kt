package com.example.home.adapter

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.home.R
import com.example.home.databaseBuku.Comment

class commentAdapter (var data :ArrayList<Comment>, var context: Activity? ) :
    RecyclerView.Adapter<commentAdapter.MyViewHolder>(){


    class MyViewHolder (view: View) : RecyclerView.ViewHolder(view) {
        val namauser = view.findViewById<TextView>(R.id.tv_username)
        val komentar = view.findViewById<TextView>(R.id.tv_komentar)
        val rating = view.findViewById<TextView>(R.id.tv_rating)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view : View = LayoutInflater.from(parent.context).inflate(R.layout.cardviewcomment, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.namauser.text = "@"+data[position].nama_user
        holder.komentar.text = data[position].komentar
        holder.rating.text = data[position].rating.toString()
    }

    override fun getItemCount(): Int {
        return data.size
    }
}